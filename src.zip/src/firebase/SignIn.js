import React, { useEffect, useState } from 'react'
import { onAuthStateChanged, signInWithPopup, signOut } from 'firebase/auth'
import { auth, googleProvider } from './firebase-config'

const SignIn = ({ children, ...attributes }) => {

    const [currUser, setCurrUser] = useState(null)

    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, u => setCurrUser(u))
        return ()=>unsubscribe()
    }, [])

    const handleSignOut = () => {
        signOut(auth)
    }

    const handleSignin = async() => {
         signInWithPopup(auth, googleProvider)
        
    }

    return (
        <div {...attributes}>
            <h6>{children}</h6>
            {currUser ?
                <>
                    <h6>{currUser.displayName} logged in.</h6>
                    <button onClick={handleSignOut}>Sign Out</button>
                   
                </> :
                <>
                    <button onClick={handleSignin}>Sign In</button>
                </>
            }

           
        </div>
    )
}

export default SignIn