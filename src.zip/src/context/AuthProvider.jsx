import { onAuthStateChanged, signInWithPopup, signOut } from "firebase/auth";
import React, { createContext, useEffect, useState } from "react";
import { auth, googleProvider } from "../firebase/firebase-config";

export const AuthContext = createContext(null);

const AuthProvider = ({ children }) => {
  const [currUser, setCurrUser] = useState(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => setCurrUser(u));
    return () => unsubscribe();
  }, []);

  const handleSignOut = () => {
    signOut(auth);
  };

  const handleSignin = async () => {
    signInWithPopup(auth, googleProvider);
  };

  return (
    <AuthContext.Provider
      value={{ currUser, setCurrUser, handleSignin, handleSignOut }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export default AuthProvider;
