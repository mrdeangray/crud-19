import React, { useContext } from "react";
import { Link } from "react-router-dom";
import { AuthContext } from "../context/AuthProvider";

const Home = () => {
  const { currUser, handleSignin, handleSignOut } = useContext(AuthContext);
  return (
    <div>
      <h1>Home</h1>
      
        {currUser ? (
          <>
            <h6>{currUser.displayName} logged in.</h6>
            <button onClick={handleSignOut}>Sign Out</button>
            <Link to={`/readtasks`}>
            <button>Read Tasks</button>
            </Link>
          </>
        ) : (
          <>
            <button onClick={handleSignin}>Sign In</button>
          </>
        )}
     
    </div>
  );
};

export default Home;
