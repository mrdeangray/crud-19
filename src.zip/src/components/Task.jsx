import axios from "axios";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const Task = ({ task }) => {
  const [score, setScore] = useState(0);

  useEffect(() => {
    getScore();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const getScore = async () => {
    try {
      const { data } = await axios(`https://api.github.com/users/${task.name}`);
      setScore(data.public_repos);
    } catch (error) {
      setScore("err");
    }
  };

  return (
    <div className="box">
      <span>{task.name}</span>
      <span>{score}</span>
      <Link to={`/update/${task.id}`}>Update</Link>
      <Link to={`/delete/${task.id}`}>Delete</Link>
    </div>
  );
};

export default Task;
