import React, { useContext, useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { TaskContext } from "../context/TaskProvider";
import styled from "styled-components";



const Msg = styled.p`
  font-size: 30px;
  color: white;
`;

const DeleteTask = () => {
  const { id } = useParams();
  const { tasks, setTasks } = useContext(TaskContext);
  const [isUpdating, setIsUpdating] = useState(false);
  const [currTask, setCurrTask] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    const curr = tasks.find((task) => task.id === id);
    setCurrTask(curr);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleDelete = (event) => {
    event.preventDefault();

    const newTasks = tasks.filter((task) => task.id !== id);
    setTasks(newTasks);
    localStorage.setItem("crud-18-tasks", JSON.stringify(newTasks));
    setIsUpdating(true);
    setTimeout(() => {
      navigate(`/`);
      setIsUpdating(false);
    }, 2000);
  };

  return (
    <div className="App">
      <div className="sub-header">
        <Link to={`/readtasks`}>Back</Link>
        <h6>DeleteTask: {currTask.name}</h6>
      </div>
      <div className="left"></div>
      <div className="sub-main">
        <button onClick={handleDelete}>Delete</button>
        <div>
          {tasks?.map((task) => {
            return <span key={task.id}>{task.name}, </span>;
          })}
        </div>
      </div>
      <div className="right"></div>
      <div className="footer">{isUpdating && <Msg>Deleting...</Msg>}</div>
    </div>
  );
};

export default DeleteTask;
