import React, { useContext } from "react";
import { AuthContext } from "../context/AuthProvider";

const Header = () => {
  const { currUser } = useContext(AuthContext);
  return (
    <nav className="header">
      <h1>CRUD-18</h1>
      <ul>
        <li>List 1</li>
        <li>List 1</li>
        <li>List 1</li>
      </ul>
      <h5>{currUser?.displayName}</h5>
    </nav>
  );
};

export default Header;
