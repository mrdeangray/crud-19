import React, { useContext } from "react";
import { Link } from "react-router-dom";
import { TaskContext } from "../context/TaskProvider";
import Task from "./Task";

const ReadTasks = () => {
  const { tasks } = useContext(TaskContext);
  return (
    <div className="main">
      <div className="sub-header">
        <Link to={`/`}>Back</Link>
        <h6>ReadTasks</h6>
      </div>

      <div  className="sub-main">
        <Link to={`/create`}>
        <button>Create Task</button>
        </Link>
        {
          tasks.map((task)=>{
            return <Task task={task}/>
          })
        }
      </div>
   
     
    </div>
  );
};

export default ReadTasks;
