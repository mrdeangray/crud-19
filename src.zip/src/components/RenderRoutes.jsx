import React from "react";
import { Route, Routes } from "react-router-dom";
import ReadTasks from "./ReadTasks";
import SignIn from "../firebase/SignIn";
import CreateTask from "./CreateTask";
import UpdateTask from "./UpdateTask";
import DeleteTask from "./DeleteTask";
import Home from "../pages/Home";
import Contact from "../pages/Contact";
import Navigation from "./Navigation";

const RenderRoutes = () => {
  return (
    <div className="main">
      <Navigation />
      <div className="right">
        <Routes>
          <Route exact path="/" element={<Home />} />
          <Route exact path="/contact" element={<Contact />} />
          <Route exact path="/readtasks" element={<ReadTasks />} />
          <Route exact path="/sigin" element={<SignIn />} />
          <Route exact path="/create" element={<CreateTask />} />
          <Route exact path="/update/:id" element={<UpdateTask />} />
          <Route exact path="/delete/:id" element={<DeleteTask />} />
        </Routes>
      </div>
    </div>
  );
};

export default RenderRoutes;
