import React, { useContext, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { TaskContext } from "../context/TaskProvider";
import styled from "styled-components";
import { v4 as uuid } from "uuid";

const Input = styled.input`
  margin-top: 20px;
  border: 2px solid blue;
  font-size: 20px;
  border-radius: 20px;
`;

const Msg = styled.p`
  font-size: 30px;
  color: white;
`;

const CreateTask = () => {
  const { tasks, setTasks } = useContext(TaskContext);
  const [inputValue, setInputValue] = useState("");
  const [isUpdating, setIsUpdating] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = (event) => {
    event.preventDefault();
    const task = {};
    task.id = uuid();
    task.score = 0;
    task.name = inputValue;
    const newTasks = [...tasks, task];
    setTasks(newTasks);
    setInputValue("");
    localStorage.setItem("crud-18-tasks", JSON.stringify(newTasks));
    setIsUpdating(true);
    setTimeout(() => {
      navigate(`/`);
      setIsUpdating(false);
    }, 2000);
  };

  const handleChange = (event) => {
    setInputValue(event.target.value);
  };

  return (
    <div >
      <div className="sub-header">
        <Link to={`/readtasks`}>Back</Link>
        <h6>CreateTask</h6>
      </div>
      <div >
        <form onSubmit={handleSubmit}>
          <Input value={inputValue} autoFocus onChange={handleChange} />
        </form>
        {tasks?.map((task) => {
          return <span key={task.id}>{task.name}, </span>;
        })}
      </div>

      <div className="footer">{isUpdating && <Msg>Creating...</Msg>}</div>
    </div>
  );
};

export default CreateTask;
