import "./App.css";
import TaskProvider from "./context/TaskProvider";
import RenderRoutes from "./components/RenderRoutes";
import AuthProvider from "./context/AuthProvider";
import Header from "./components/Header";
import Navigation from "./components/Navigation";

function App() {
  return (
    <div className="App-main">
      <TaskProvider>
        <AuthProvider>
          <Header />
          <RenderRoutes />
        </AuthProvider>
      </TaskProvider>
    </div>
  );
}

export default App;
